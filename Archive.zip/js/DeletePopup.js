class DeletePopup {
	constructor(msg) {
		this.msg = msg;
	}
}
